package com.ryan.util;

public enum Environment {
	DEVELOPMENT,
	TEST,
	PRODUCTION

}
